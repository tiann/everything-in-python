<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>main</name>
    <message>
        <location filename="Ui_filesearch.py" line="308"/>
        <source>FileSearcher</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="309"/>
        <source>the file system tree</source>
        <translation>文件系统</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="310"/>
        <source>stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="311"/>
        <source>All Files</source>
        <translation>所有文件</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="312"/>
        <source>Document</source>
        <translation>文档</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="313"/>
        <source>Music</source>
        <translation>音乐</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="314"/>
        <source>Picture</source>
        <translation>图片</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="315"/>
        <source>Video</source>
        <translation>视频</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="316"/>
        <source>Application</source>
        <translation>应用程序</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="317"/>
        <source>Others</source>
        <translation>其他</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="318"/>
        <source>&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="319"/>
        <source>give a stretch of the file</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="320"/>
        <source>&lt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="321"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="322"/>
        <source>edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="323"/>
        <source>option</source>
        <translation>选项</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="347"/>
        <source>help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="346"/>
        <source>setting</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="326"/>
        <source>language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="327"/>
        <source>assign directory</source>
        <translation>指定目录</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="328"/>
        <source>new index</source>
        <translation>新建索引</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="329"/>
        <source>create a new index</source>
        <translation>创建一个新的索引文件，第一次或者文件系统改变较大时使用</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="330"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="331"/>
        <source>update index</source>
        <translation>更新索引</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="332"/>
        <source>update the index,if you have a index already,it is much faster</source>
        <translation>更新索引文件，文件系统变化不大时推荐使用，速度较快</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="333"/>
        <source>Ctrl+U</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="335"/>
        <source>cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="336"/>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="338"/>
        <source>copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="339"/>
        <source>Ctrl+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="341"/>
        <source>paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="342"/>
        <source>Ctrl+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="344"/>
        <source>select all</source>
        <translation>全选</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="345"/>
        <source>Ctrl+A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="348"/>
        <source>F1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="349"/>
        <source>about...</source>
        <translation>关于...</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="350"/>
        <source>match whole word</source>
        <translation>全部匹配</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="351"/>
        <source>just match the whole word</source>
        <translation>全部匹配整个单词</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="352"/>
        <source>use wildcard</source>
        <translation>使用通配符</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="353"/>
        <source>match directory when search,is is closed by default</source>
        <translation>使用通配符进行搜索，*代表任意数目的任意字符？代表一个任意字符，默认不使用</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="354"/>
        <source>case sensitive</source>
        <translation>区分大小写</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="355"/>
        <source>dont&apos;t ignore the case of the word,it is closed by default</source>
        <translation>区分大小写，默认关闭</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="356"/>
        <source>export...</source>
        <translation>导出...</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="357"/>
        <source>exit...</source>
        <translation>退出...</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="358"/>
        <source>exit the application</source>
        <translation>退出程序</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="359"/>
        <source>Esc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="360"/>
        <source>regex expression</source>
        <translation>正则表达式</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="361"/>
        <source>use the regular expression to search,it is closed by default</source>
        <translation>使用正则表达式进行搜索，不建议普通用户使用</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="362"/>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message utf8="true">
        <location filename="Ui_filesearch.py" line="363"/>
        <source>中文-简体</source>
        <translation>中文-简体</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="364"/>
        <source>normal mode</source>
        <translation>普通模式</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="365"/>
        <source>Contact us</source>
        <translation>联系我们</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="366"/>
        <source>All Volume</source>
        <translation>全盘</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="367"/>
        <source>Select...</source>
        <translation>选择...</translation>
    </message>
</context>
<context>
    <name>qApp</name>
    <message>
        <location filename="filesearch.py" line="55"/>
        <source>Cannot open database</source>
        <translation>不能打开数据库</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="55"/>
        <source>Unable to establish a database connection.
This example needs SQLite support. Please read the Qt SQL driver documentation for information how to build it.

Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="filesearch.py" line="167"/>
        <source>All Volume</source>
        <translation>全盘</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="188"/>
        <source>open</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="189"/>
        <source>open directory</source>
        <translation>打开目录</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="190"/>
        <source>copy file name to clipboard</source>
        <translation>复制文件名到剪切板</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="191"/>
        <source>copy directory name to clipboard</source>
        <translation>复制全部路径到剪切板</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="209"/>
        <source>FileName</source>
        <translation>文件名</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="210"/>
        <source>Directory</source>
        <translation>所在目录</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="211"/>
        <source>Modefied Time</source>
        <translation>修改时间</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="220"/>
        <source> -Filesearch- Location: </source>
        <translation> -Filesearch- 所在位置:</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="349"/>
        <source>Index Finished!</source>
        <translation>新建索引完成！</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="357"/>
        <source>Update Finished!</source>
        <translation>更新索引完成！</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="416"/>
        <source>Filesearch- Location: All Volume</source>
        <translation>Filesearch- 所在位置: 全盘</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="422"/>
        <source>Select Directory</source>
        <translation>选择目录</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="431"/>
        <source>Filesearch- Location:</source>
        <translation>Filesearch- 所在位置:</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="461"/>
        <source>help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="466"/>
        <source>about filesearch</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="466"/>
        <source>&lt;p&gt;Filesearch Version: 0.13.1&lt;/p&gt;Created by TianWeishu, Chengxu, Huxiaoling&lt;br /&gt;Copyright (c) 2012-12 All Rights Reserved&lt;p&gt;Contact us &lt;a href=&quot;mailto:twsxtd@gmail.com&quot;&gt;twsxtd@gmail.com&lt;/a&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;Filesearch 版本: 0.13.1&lt;/p&gt;Created by 田维术,胡晓灵,程旭&lt;br /&gt;Copyright (c) 2012-12 All Rights Reserved&lt;p&gt;联系我们 &lt;a href=&quot;mailto:twsxtd@gmail.com&quot;&gt;twsxtd@gmail.com&lt;/a&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="754"/>
        <source>loading core module...</source>
        <translation>加载核心模块...</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="757"/>
        <source>update data...</source>
        <translation>更新数据...</translation>
    </message>
    <message>
        <location filename="filesearch.py" line="762"/>
        <source>starting...</source>
        <translation>正在启动...</translation>
    </message>
</context>
</TS>
