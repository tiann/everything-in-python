<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>main</name>
    <message>
        <location filename="Ui_filesearch.py" line="266"/>
        <source>FileSearcher</source>
        <translation type="unfinished">FileSearcher</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="268"/>
        <source>File Name</source>
        <translation type="unfinished">文件名</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="269"/>
        <source>Directory</source>
        <translation type="unfinished">所在目錄</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="270"/>
        <source>last modefied time</source>
        <translation type="unfinished">修改時間</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="271"/>
        <source>is directyory</source>
        <translation type="unfinished">是否目錄</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="275"/>
        <source>  ALL</source>
        <translation type="unfinished">全部</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="277"/>
        <source>  Documents</source>
        <translation type="unfinished">文檔</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="279"/>
        <source>  Vedio</source>
        <translation type="unfinished">視頻</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="281"/>
        <source>  Music</source>
        <translation type="unfinished">音樂</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="283"/>
        <source>  Picture</source>
        <translation type="unfinished">圖片</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="285"/>
        <source>  Others</source>
        <translation type="unfinished">其他</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="287"/>
        <source>File</source>
        <translation type="unfinished">文件</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="288"/>
        <source>edit</source>
        <translation type="unfinished">編輯</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="289"/>
        <source>option</source>
        <translation type="unfinished">選項</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="298"/>
        <source>help</source>
        <translation type="unfinished">幫助</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="291"/>
        <source>new index</source>
        <translation type="unfinished">新建索引</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="292"/>
        <source>update index</source>
        <translation type="unfinished">更新索引</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="293"/>
        <source>cut</source>
        <translation type="unfinished">剪切</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="294"/>
        <source>copy</source>
        <translation type="unfinished">複製</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="295"/>
        <source>paste</source>
        <translation type="unfinished">扎貼</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="296"/>
        <source>select all</source>
        <translation type="unfinished">全選</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="297"/>
        <source>setting</source>
        <translation type="unfinished">設置</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="299"/>
        <source>about...</source>
        <translation type="unfinished">關於</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="300"/>
        <source>match word</source>
        <translation type="unfinished">匹配全詞</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="301"/>
        <source>match directory</source>
        <translation type="unfinished">匹配目錄</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="302"/>
        <source>care uppercase</source>
        <translation type="unfinished">區分大小寫</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="303"/>
        <source>export...</source>
        <translation type="unfinished">導出</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="304"/>
        <source>exit</source>
        <translation type="unfinished">脫出</translation>
    </message>
    <message>
        <location filename="Ui_filesearch.py" line="305"/>
        <source>regex expression</source>
        <translation type="unfinished">正則表達式</translation>
    </message>
</context>
</TS>
